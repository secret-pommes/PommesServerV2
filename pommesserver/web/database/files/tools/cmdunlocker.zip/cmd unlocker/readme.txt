thanks for downloading this from secret's database :>


CMD UNLOCKER V2 [24-10-2022]

-Looks better
-Easier to use
-New codebase (completly rewritten)
-Cant get deleted by my school lol (dont ask why or how lol)


-made by: secret_pommes#1337
-provided by: secret's database (last check: 24-10-2022 :: 17:19 MEZ)